export enum UserType {
    //** UserType value must match the Id of UserType in the Db */
    Customer = 2,
    Staff = 1,
    Driver = 3
}