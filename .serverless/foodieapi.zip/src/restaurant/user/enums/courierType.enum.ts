export enum CourierType {
    //** CourierType value must match the Id of CourierType in the Db */
    Default = 1,
    Car = 2
}