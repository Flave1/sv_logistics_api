export enum Restaurant {
    //** Default value must match the Id of Default Restaurant */
    Default = 1 
  }