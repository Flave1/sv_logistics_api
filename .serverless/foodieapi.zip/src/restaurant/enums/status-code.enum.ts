export enum Status {
    Success = "00",
    OtherErrors = "99"
  }