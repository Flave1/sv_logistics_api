  export class RedisDto1 {
    id: string;
    data: any;
    key: string;
  }

  export class RedisDto2 {
    data: any;
    key: string;
  }